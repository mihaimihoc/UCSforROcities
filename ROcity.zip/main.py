import tkinter as tk
import other

if __name__ == "__main__":
    root = tk.Tk()
    app = other.UCSVisualizer(root)
    root.mainloop()
